str1=input()
strlen=k=len(str1)
str2=list(str1)
flag=0
#print(str1,str2)
for i in range(0,strlen//2):
    if str2[i]!=str2[k-1]:
        flag=0
        break
    else:
        flag=1
    k=k-1
if flag==1:
    print("palindrome")
else:
    print("not a palin")
