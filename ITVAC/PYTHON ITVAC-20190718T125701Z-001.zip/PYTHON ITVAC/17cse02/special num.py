a = int(input())
n=a
summ=0
prod=1
while n>0:
    summ+=n%10
    prod*=n%10
    n=n//10
if summ+prod==a:
    print("special")
else:
    print("not spl")
