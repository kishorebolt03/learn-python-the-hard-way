n=int(input())

i=n
i=i//10
k=i%10
if k%3==0:
    print("TRENDY")
else:
    print("not trendy")
